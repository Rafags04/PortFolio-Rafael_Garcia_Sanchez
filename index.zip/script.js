/**
 * ==========================================================================
 * PORTFOLIO INTERACTIVO - LÓGICA COMPLETA, FORMATOS & DATOS EN VIVO
 * ==========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Inicializar iconos Lucide y año dinámico
  if (window.lucide) {
    window.lucide.createIcons();
  }

  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Estado global de la aplicación
  const appState = {
    persona: 'recruiter',
    overclock: false,
    ecoMode: false,
    matrixRain: false,
    classicCvOpen: false,
    selectedEndpoint: '/api/metrics',
    pods: [
      { id: 'api-gateway', cpu: 22 },
      { id: 'worker-01', cpu: 28 },
      { id: 'redis-cache', cpu: 16 }
    ],
    trafficSpike: false,
    githubData: null
  };

  // ==========================================================================
  // UTILIDAD DE NOTIFICACIONES (TOASTS / EASTER EGGS)
  // ==========================================================================
  let toastTimer = null;
  function showToast(title, description) {
    const toast = document.getElementById('achievement-toast');
    const titleEl = document.getElementById('toast-title');
    const descEl = document.getElementById('toast-desc');
    if (!toast || !titleEl || !descEl) return;

    titleEl.textContent = title;
    descEl.textContent = description;
    toast.classList.add('is-visible');

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 4200);
  }

  // ==========================================================================
  // MENÚ MÓVIL, HEADER SCROLL & SCROLL SPY
  // ==========================================================================
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.toggle('is-active');
      navToggle.setAttribute('aria-expanded', String(navMenu.classList.contains('is-active')));
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const spySections = document.querySelectorAll('.stage-section[id]');
  const hudPills = document.querySelectorAll('.hud-pill');

  const onScrollSpy = () => {
    const scrollY = window.pageYOffset;
    const windowH = window.innerHeight;

    spySections.forEach((section) => {
      const top = section.offsetTop - windowH * 0.38;
      const height = section.offsetHeight;
      const id = section.getAttribute('id');

      if (scrollY >= top && scrollY < top + height) {
        const navTargetHref = (id === 'skills-backend' || id === 'skills-storage')
          ? '#skills-frontend'
          : `#${id}`;
        navLinks.forEach((link) => {
          link.classList.toggle('active', link.getAttribute('href') === navTargetHref);
        });
        hudPills.forEach((pill) => {
          pill.classList.toggle('active', pill.getAttribute('href') === `#${id}`);
        });
      }
    });
  };

  window.addEventListener('scroll', onScrollSpy, { passive: true });
  onScrollSpy();

  const header = document.getElementById('header');
  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        header.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.7)';
        header.style.borderColor = 'rgba(255, 255, 255, 0.14)';
      } else {
        header.style.boxShadow = 'none';
        header.style.borderColor = 'var(--border-color)';
      }
    }, { passive: true });
  }

  // ==========================================================================
  // CONTROLES DEL HUD 3D, TEMAS RGB, OVERCLOCK & MODO ECO
  // ==========================================================================
  const themeBtns = document.querySelectorAll('.theme-btn');
  function applyTheme(themeKey) {
    themeBtns.forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-theme') === themeKey);
    });
    if (window.pcViewer && typeof window.pcViewer.setTheme === 'function') {
      window.pcViewer.setTheme(themeKey);
    }
  }

  themeBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      applyTheme(btn.getAttribute('data-theme'));
    });
  });

  window.addEventListener('pc3d:theme', (e) => {
    if (!e.detail) return;
    themeBtns.forEach((b) => {
      b.classList.toggle('active', b.getAttribute('data-theme') === e.detail.themeKey);
    });
  });

  const reassembleBtn = document.getElementById('btn-reassemble-pc');
  if (reassembleBtn) {
    reassembleBtn.addEventListener('click', () => {
      if (window.pcViewer) window.pcViewer.setManualDisassembly(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Sincronización de sliders de despiece manual (HUD + Demo Viva 1)
  const hudSlider = document.getElementById('hud-disassembly-slider');
  const hudResetBtn = document.getElementById('hud-disassembly-reset');
  const demoSlider = document.getElementById('demo-disassembly-slider');
  const demoSliderVal = document.getElementById('demo-disassembly-val');
  const demoAutoBtn = document.getElementById('demo-disassembly-auto');

  function setDisassemblyPercent(pct) {
    const safePct = Math.max(0, Math.min(100, Number(pct) || 0));
    if (hudSlider) hudSlider.value = String(safePct);
    if (demoSlider) demoSlider.value = String(safePct);
    if (demoSliderVal) demoSliderVal.textContent = `${safePct}%`;
    if (window.pcViewer && typeof window.pcViewer.setManualDisassembly === 'function') {
      window.pcViewer.setManualDisassembly(safePct / 100);
    }
  }

  function resetDisassemblyToScroll() {
    if (window.pcViewer && typeof window.pcViewer.setManualDisassembly === 'function') {
      window.pcViewer.setManualDisassembly(null);
    }
    if (demoSliderVal) demoSliderVal.textContent = 'Auto';
  }

  if (hudSlider) {
    hudSlider.addEventListener('input', (e) => setDisassemblyPercent(e.target.value));
  }
  if (demoSlider) {
    demoSlider.addEventListener('input', (e) => setDisassemblyPercent(e.target.value));
  }
  if (hudResetBtn) hudResetBtn.addEventListener('click', resetDisassemblyToScroll);
  if (demoAutoBtn) demoAutoBtn.addEventListener('click', resetDisassemblyToScroll);

  // Overclock toggle (HUD + Demo Viva 1 + Terminal + Konami)
  const hudOverclockBtn = document.getElementById('btn-hud-overclock');
  const demoStressBtn = document.getElementById('demo-stress-btn');
  const demoHwTelemetry = document.getElementById('demo-hw-telemetry');

  function setOverclock(enabled) {
    appState.overclock = Boolean(enabled);
    if (hudOverclockBtn) hudOverclockBtn.classList.toggle('is-active', appState.overclock);
    if (demoStressBtn) {
      demoStressBtn.classList.toggle('is-active', appState.overclock);
      demoStressBtn.textContent = appState.overclock ? '❄️ Detener Stress Test' : '🔥 Stress Test';
    }
    if (window.pcViewer && typeof window.pcViewer.setOverclockMode === 'function') {
      window.pcViewer.setOverclockMode(appState.overclock);
    }
    updateTelemetryReadout();
  }

  if (hudOverclockBtn) {
    hudOverclockBtn.addEventListener('click', () => setOverclock(!appState.overclock));
  }
  if (demoStressBtn) {
    demoStressBtn.addEventListener('click', () => setOverclock(!appState.overclock));
  }

  // Modo Eco (desactiva bloom y partículas para batería/móvil)
  const ecoBtn = document.getElementById('btn-eco-mode');
  function setEcoMode(enabled) {
    appState.ecoMode = Boolean(enabled);
    if (ecoBtn) {
      ecoBtn.classList.toggle('is-active', appState.ecoMode);
      ecoBtn.setAttribute('aria-pressed', String(appState.ecoMode));
    }
    if (window.pcViewer && typeof window.pcViewer.setEcoMode === 'function') {
      window.pcViewer.setEcoMode(appState.ecoMode);
    }
    showToast(
      appState.ecoMode ? 'Modo Eco Activado' : 'Modo Alto Rendimiento',
      appState.ecoMode ? 'Post-procesado 3D reducido para ahorrar batería.' : 'Bloom óptico PBR y partículas activados.'
    );
  }
  if (ecoBtn) {
    ecoBtn.addEventListener('click', () => setEcoMode(!appState.ecoMode));
  }

  // Telemetría térmica en vivo
  const tempEl = document.getElementById('hud-temp-val');
  function updateTelemetryReadout() {
    const baseTemp = appState.overclock ? 62 : 37;
    const temp = Math.round(baseTemp + Math.sin(Date.now() * 0.001) * 3 + Math.random() * 1.4);
    if (tempEl) tempEl.textContent = `${temp}°C`;
    if (demoHwTelemetry) {
      const rpm = appState.overclock ? '2450 RPM' : '1150 RPM';
      const fps = appState.ecoMode ? '60 FPS ECO' : '60 FPS PBR';
      demoHwTelemetry.textContent = `${fps} · ${rpm} · ${temp}°C`;
    }
  }
  setInterval(updateTelemetryReadout, 1800);
  updateTelemetryReadout();

  // Evento cuando el usuario hace clic en una pieza 3D real
  window.addEventListener('pc3d:partclick', (e) => {
    if (e.detail) {
      showToast('Inspección 3D', `Componente seleccionado: ${e.detail.label}`);
    }
  });

  // ==========================================================================
  // 1. CURSOR PERSONALIZADO & FONDO GENERATIVO / MATRIX RAIN
  // ==========================================================================
  const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isFinePointer = window.matchMedia && window.matchMedia('(pointer: fine)').matches;

  function initCustomCursor() {
    const cursor = document.getElementById('custom-cursor');
    const dot = document.getElementById('custom-cursor-dot');
    const label = document.getElementById('cursor-label');
    if (!cursor || !dot || !isFinePointer || prefersReducedMotion) return;

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let curX = mouseX;
    let curY = mouseY;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      dot.style.left = `${mouseX}px`;
      dot.style.top = `${mouseY}px`;
      cursor.classList.add('is-visible');
      dot.classList.add('is-visible');

      const interactive = e.target.closest('a, button, input, .metro-station, .project-card');
      cursor.classList.toggle('is-interactive', Boolean(interactive));

      if (label) {
        label.textContent = document.body.dataset.cursorLabel || '';
      }
    });

    document.addEventListener('mouseleave', () => {
      cursor.classList.remove('is-visible');
      dot.classList.remove('is-visible');
    });

    function loopCursor() {
      curX += (mouseX - curX) * 0.22;
      curY += (mouseY - curY) * 0.22;
      cursor.style.left = `${curX}px`;
      cursor.style.top = `${curY}px`;
      requestAnimationFrame(loopCursor);
    }
    requestAnimationFrame(loopCursor);
  }
  initCustomCursor();

  // Fondo generativo reactivo al ratón/scroll + Modo Lluvia Matrix
  const bgCanvas = document.getElementById('generative-bg-canvas');
  let matrixDrops = [];

  function initGenerativeBackground() {
    if (!bgCanvas || prefersReducedMotion) return;
    const ctx = bgCanvas.getContext('2d');
    if (!ctx) return;

    let width = (bgCanvas.width = window.innerWidth);
    let height = (bgCanvas.height = window.innerHeight);
    let pointer = { x: width * 0.5, y: height * 0.5 };

    const nodeCount = width < 768 ? 22 : 44;
    const nodes = Array.from({ length: nodeCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: 1.2 + Math.random() * 1.5
    }));

    const initMatrixColumns = () => {
      const cols = Math.floor(width / 18);
      matrixDrops = Array.from({ length: cols }, () => Math.floor(Math.random() * -40));
    };
    initMatrixColumns();

    window.addEventListener('mousemove', (e) => {
      pointer.x = e.clientX;
      pointer.y = e.clientY;
    }, { passive: true });

    window.addEventListener('resize', () => {
      width = bgCanvas.width = window.innerWidth;
      height = bgCanvas.height = window.innerHeight;
      initMatrixColumns();
    });

    function drawFrame() {
      requestAnimationFrame(drawFrame);
      if (appState.classicCvOpen || (appState.ecoMode && !appState.matrixRain)) {
        ctx.clearRect(0, 0, width, height);
        return;
      }

      if (appState.matrixRain) {
        ctx.fillStyle = 'rgba(5, 10, 14, 0.14)';
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#10b981';
        ctx.font = '14px "JetBrains Mono", monospace';
        const chars = '01RAFA<>/{}[]$#=+-*アイウエオカキクケコ';
        for (let i = 0; i < matrixDrops.length; i++) {
          const text = chars.charAt(Math.floor(Math.random() * chars.length));
          const x = i * 18;
          const y = matrixDrops[i] * 18;
          ctx.fillText(text, x, y);
          if (y > height && Math.random() > 0.975) {
            matrixDrops[i] = 0;
          }
          matrixDrops[i]++;
        }
        return;
      }

      ctx.clearRect(0, 0, width, height);
      const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00f0ff';
      const scrollRatio = window.scrollY / Math.max(1, document.documentElement.scrollHeight - height);

      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.vx;
        n.y += n.vy + (scrollRatio - 0.5) * 0.25;

        if (n.x < 0 || n.x > width) n.vx *= -1;
        if (n.y < 0 || n.y > height) n.vy *= -1;

        const dxP = pointer.x - n.x;
        const dyP = pointer.y - n.y;
        const distP = Math.hypot(dxP, dyP);
        if (distP < 180) {
          ctx.beginPath();
          ctx.strokeStyle = accentColor;
          ctx.globalAlpha = (1 - distP / 180) * 0.24;
          ctx.lineWidth = 1;
          ctx.moveTo(n.x, n.y);
          ctx.lineTo(pointer.x, pointer.y);
          ctx.stroke();
        }

        for (let j = i + 1; j < nodes.length; j++) {
          const m = nodes[j];
          const dist = Math.hypot(n.x - m.x, n.y - m.y);
          if (dist < 130) {
            ctx.beginPath();
            ctx.strokeStyle = accentColor;
            ctx.globalAlpha = (1 - dist / 130) * 0.12;
            ctx.lineWidth = 0.8;
            ctx.moveTo(n.x, n.y);
            ctx.lineTo(m.x, m.y);
            ctx.stroke();
          }
        }

        ctx.globalAlpha = 0.38;
        ctx.fillStyle = accentColor;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    requestAnimationFrame(drawFrame);
  }
  initGenerativeBackground();

  function setMatrixRain(enabled) {
    appState.matrixRain = Boolean(enabled);
    if (appState.matrixRain) {
      applyTheme('matrix');
      showToast('Modo Matrix Activado', 'Lluvia de código en tiempo real sobre el canvas.');
    } else {
      showToast('Modo Matrix Desactivado', 'Fondo generativo restaurado.');
    }
  }

  // ==========================================================================
  // 2. SELECTOR DE PERFIL ("CV QUE SE ADAPTA")
  // ==========================================================================
  const PERSONA_DATA = {
    recruiter: {
      focusTag: 'ENFOQUE: IMPACTO, FIABILIDAD & ENTREGA EN EQUIPO',
      summary: 'Perfil orientado a resultados: código mantenible en producción, entrega ágil, pruebas y rápida integración en equipos multidisciplinares.',
      kpis: ['Full-Stack Web & 3D', 'APIs Escalables', 'Mobile-First & A11y'],
      heroRole: 'Desarrollador de Software Full-Stack',
      heroDesc: 'Diseño y construyo productos digitales fiables de principio a fin: desde APIs en Node.js/Python/PostgreSQL hasta interfaces rápidas y accesibles. Haz scroll o haz clic en las piezas del PC 3D para ver cada competencia.',
      aboutIntro: 'Así como un chasis de alta ingeniería aporta orden y fiabilidad, priorizo la claridad arquitectónica, la documentación y el trabajo colaborativo con CI/CD.',
      frontendNote: 'Interfaces accesibles, responsive y fluidas (60 FPS) pensadas para maximizar retención y usabilidad en cualquier dispositivo.',
      backendNote: 'Servicios estables, autenticación segura y contratos API claros que reducen incidencias y facilitan el mantenimiento del equipo.',
      storageNote: 'Modelado relacional sólido, uso estratégico de caché y contenedores Docker listos para entornos de producción reproducibles.',
      cvSubtitle: 'Desarrollador Full-Stack · Enfoque en fiabilidad, calidad de código, escalabilidad y experiencia de usuario.',
      cvSummary: 'Ingeniero de software full-stack con sólida base en Node.js, Python, Java, React, PostgreSQL y Docker. Acostumbrado a entregar producto funcional, documentar decisiones técnicas y cuidar métricas reales de rendimiento y accesibilidad.',
      projects: {
        p1: {
          problem: 'Los portfolios tradicionales no permiten comprobar rápidamente el nivel técnico real en frontend y arquitectura.',
          solution: 'Experiencia interactiva en 3D combinada con Modo CV Clásico instantáneo para evaluación en menos de 30 segundos.'
        },
        p2: {
          problem: 'Consultas lentas bajo concurrencia y gestión frágil de sesiones de usuario en tiempo real.',
          solution: 'Backend asíncrono con caché Redis, PostgreSQL transaccional y JWT con rotación segura y trazabilidad.'
        },
        p3: {
          problem: 'Despliegues manuales propensos a fallos que frenaban la entrega continua de nuevas funcionalidades.',
          solution: 'Microservicios dockerizados con balanceo dinámico y automatización completa de pruebas y deploy.'
        }
      }
    },
    developer: {
      focusTag: 'ENFOQUE: ARQUITECTURA, PATRONES, SHADERS & ZERO-BUILD',
      summary: 'Sin frameworks innecesarios cuando no toca: Three.js procedimental con raycasting, PMREM studio lighting, parsers propios y APIs asíncronas.',
      kpis: ['Three.js + Raycaster', 'PBR & UnrealBloom', 'REST / Redis / Docker'],
      heroRole: 'Creative & Systems Software Engineer',
      heroDesc: 'Todo este PC 3D está modelado por código sin .glb externos, con UnrealBloomPass, raycasting directo y estado reactivo en ES6+. Abre el modo VS Code IDE o escribe en la terminal.',
      aboutIntro: 'Código desacoplado, separación limpia entre motor WebGL y capa de estado DOM, manejo explícito de rate-limits y foco en rendimiento real.',
      frontendNote: 'Pipeline WebGL con PMREM environment maps, texturas procedimentales Canvas 2D dinámicas, CSS tokens reactivos y cero bloqueo del hilo principal.',
      backendNote: 'Arquitecturas orientadas a eventos, control de concurrencia, validación estricta, JWT stateless y optimización de latencia p95.',
      storageNote: 'Índices compuestos en PostgreSQL, TTL caching con Redis, persistencia ACID y contenedores multi-stage ligeros en Docker.',
      cvSubtitle: 'Creative & Full-Stack Engineer · Arquitectura limpia, WebGL procedimental, APIs de baja latencia y DevOps.',
      cvSummary: 'Desarrollador apasionado por entender cómo funcionan las capas inferiores: desde renderizado PBR en Three.js y raycasting hasta diseño de APIs en Node.js/Python, caching en Redis y pipelines automatizados en GitHub Actions.',
      projects: {
        p1: {
          problem: 'Cargar modelos .glb externos pesa decenas de megabytes y bloquea el First Contentful Paint.',
          solution: 'Geometrías y texturas PCB/OLED generadas proceduralmente en JavaScript + caché y control de pixelRatio.'
        },
        p2: {
          problem: 'Contención en base de datos relacional al consultar métricas de telemetría con alta frecuencia.',
          solution: 'Patrón cache-aside en Redis, pooling de conexiones en PostgreSQL y endpoints stateless optimizados.'
        },
        p3: {
          problem: 'Acoplamiento monolítico entre módulos que impedía escalar nodos de trabajo de forma independiente.',
          solution: 'Contenedores Docker aislados por dominio, healthchecks automáticos y distribución dinámica de carga.'
        }
      }
    },
    client: {
      focusTag: 'ENFOQUE: PRODUCTO FINAL, VELOCIDAD & DIFERENCIACIÓN DIGITAL',
      summary: 'Transformo ideas en aplicaciones web memorables, rápidas en móvil y preparadas para captar clientes, automatizar procesos y escalar sin sorpresas.',
      kpis: ['Webs Memorables', 'Carga Ultrarrápida', 'Listo para Escalar'],
      heroRole: 'Consultor & Desarrollador de Producto Digital',
      heroDesc: 'Construyo soluciones web que destacan frente a la competencia y funcionan de maravilla en cualquier móvil. Prueba las demos interactivas en vivo o pregúntame directamente en el chat.',
      aboutIntro: 'Me encargo tanto de que tu proyecto cause una primera impresión inolvidable como de que la infraestructura interna sea sólida y segura.',
      frontendNote: 'Diseños modernos, claros y adaptados a móvil primero, para que tus usuarios comprendan y disfruten el producto al instante.',
      backendNote: 'Sistemas fiables que automatizan cobros, paneles de gestión, usuarios y datos en tiempo real sin caídas.',
      storageNote: 'Tus datos protegidos, copias seguras y arquitectura preparada para crecer cuando tu negocio multiplique usuarios.',
      cvSubtitle: 'Desarrollador de Producto Digital · Soluciones web diferenciadoras, rápidas, seguras y orientadas a negocio.',
      cvSummary: 'Ayudo a empresas y equipos a lanzar plataformas web modernas, paneles de control a medida y experiencias interactivas que convierten visitas en oportunidades reales, cuidando velocidad, móvil y escalabilidad.',
      projects: {
        p1: {
          problem: 'Webs corporativas genéricas que no retienen la atención ni comunican innovación.',
          solution: 'Presentación interactiva en 3D que convierte al visitante en protagonista y multiplica el tiempo de permanencia.'
        },
        p2: {
          problem: 'Falta de visibilidad en tiempo real sobre métricas de negocio, usuarios y estado del servicio.',
          solution: 'Panel analítico unificado con actualización instantánea, alertas claras y acceso seguro por roles.'
        },
        p3: {
          problem: 'Webs que se caen o ralentizan justo en campañas de lanzamiento o picos de visitas.',
          solution: 'Infraestructura elástica por módulos capaz de absorber picos de tráfico sin interrupciones.'
        }
      }
    }
  };

  const personaBtns = document.querySelectorAll('.persona-btn');
  function setVisitorPersona(personaKey) {
    const data = PERSONA_DATA[personaKey];
    if (!data) return;
    appState.persona = personaKey;

    personaBtns.forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-persona') === personaKey);
    });

    const setTxt = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setTxt('persona-focus-tag', data.focusTag);
    setTxt('persona-summary', data.summary);
    setTxt('hero-role-text', data.heroRole);
    setTxt('hero-description-text', data.heroDesc);
    setTxt('about-persona-intro', data.aboutIntro);
    setTxt('frontend-persona-note', data.frontendNote);
    setTxt('backend-persona-note', data.backendNote);
    setTxt('storage-persona-note', data.storageNote);
    setTxt('cv-adaptive-subtitle', data.cvSubtitle);
    setTxt('cv-adaptive-summary', data.cvSummary);

    const kpisEl = document.getElementById('persona-kpis');
    if (kpisEl) {
      kpisEl.innerHTML = data.kpis.map((k) => `<span class="kpi-chip">${k}</span>`).join('');
    }

    ['p1', 'p2', 'p3'].forEach((pKey) => {
      const probEl = document.querySelector(`.proj-problem[data-proj="${pKey}"]`);
      const solEl = document.querySelector(`.proj-solution[data-proj="${pKey}"]`);
      if (probEl) probEl.textContent = data.projects[pKey].problem;
      if (solEl) solEl.textContent = data.projects[pKey].solution;
    });
  }

  personaBtns.forEach((btn) => {
    btn.addEventListener('click', () => setVisitorPersona(btn.getAttribute('data-persona')));
  });

  // ==========================================================================
  // 3. WIDGET "AHORA MISMO" & SCROLLYTELLING TIMELINE
  // ==========================================================================
  function initNowLiveWidget() {
    const dateEl = document.getElementById('now-updated-date');
    const jsonBtn = document.getElementById('btn-inspect-now-json');
    const jsonPreview = document.getElementById('now-json-preview');

    const nowStatusPayload = {
      updated_at: new Date().toISOString().slice(0, 10),
      source: 'github-actions/daily-status.yml',
      listening: {
        provider: 'Last.fm API',
        artist: 'Midnight Compiler',
        track: 'Synthwave Focus'
      },
      reading: 'Designing Data-Intensive Applications (M. Kleppmann)',
      learning: ['Shaders GLSL', 'WebGPU', 'Edge Caching'],
      focus: 'Optimizando experiencias 3D a 60 FPS en móvil'
    };

    if (dateEl) {
      dateEl.textContent = nowStatusPayload.updated_at;
    }
    if (jsonPreview) {
      jsonPreview.textContent = JSON.stringify(nowStatusPayload, null, 2);
    }
    if (jsonBtn && jsonPreview) {
      jsonBtn.addEventListener('click', () => {
        jsonPreview.classList.toggle('is-hidden');
      });
    }
  }
  initNowLiveWidget();

  function initScrollyTimeline() {
    const steps = document.querySelectorAll('.timeline-step');
    if (!steps.length) return;

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-in-view');
            }
          });
        },
        { threshold: 0.22 }
      );
      steps.forEach((s) => observer.observe(s));
    } else {
      steps.forEach((s) => s.classList.add('is-in-view'));
    }
  }
  initScrollyTimeline();

  // ==========================================================================
  // 4. MAPA DEL METRO TECNOLÓGICO (SVG INTERACTIVO)
  // ==========================================================================
  const METRO_STATIONS = {
    'html-css': {
      badge: 'L1 · FRONTEND & 3D',
      title: 'HTML5 / CSS3 Semántico',
      desc: 'Maquetación semántica accesible, arquitectura CSS con tokens dinámicos, Grid/Flexbox y micro-interacciones GPU-friendly a 60 FPS.',
      level: 'Avanzado',
      projects: 'Portfolio 3D, Plataforma Modular'
    },
    'react-ts': {
      badge: 'L1 · FRONTEND & 3D',
      title: 'React & TypeScript',
      desc: 'Interfaces modulares fuertemente tipadas, estado predecible, custom hooks y componentes reutilizables orientados a producto.',
      level: 'Avanzado',
      projects: 'Cloud Cluster Orchestrator'
    },
    'threejs-webgl': {
      badge: 'L1 · FRONTEND & 3D',
      title: 'Three.js / WebGL PBR',
      desc: 'Escenas tridimensionales interactivas con iluminación de estudio PMREM, shaders, post-procesado Bloom y Raycasting por componente.',
      level: 'Especialidad',
      projects: 'Explorador PC 3D'
    },
    'a11y-perf': {
      badge: 'L1 · FRONTEND & 3D',
      title: 'Accesibilidad (a11y) & 60 FPS',
      desc: 'Soporte ARIA completo, navegación por teclado, respeto a prefers-reduced-motion, Lighthouse 98+ y modo alternativo clásico.',
      level: 'Avanzado',
      projects: 'Toda la suite web'
    },
    'java-python': {
      badge: 'L2 · BACKEND & APIs',
      title: 'Python (FastAPI) & Java OOP',
      desc: 'Servicios backend robustos, automatización, scripting de datos, programación orientada a objetos y patrones de diseño limpios.',
      level: 'Avanzado',
      projects: 'Scripts CI, Motores de Datos'
    },
    'nodejs-api': {
      badge: 'L2 · BACKEND & APIs',
      title: 'Node.js & APIs REST / GraphQL',
      desc: 'APIs asíncronas de alto throughput, validación de esquemas, manejo estructurado de errores y documentación clara.',
      level: 'Avanzado',
      projects: 'Telemetry & Auth API Hub'
    },
    'jwt-auth': {
      badge: 'L2 · BACKEND & APIs',
      title: 'Seguridad JWT / OAuth 2.0',
      desc: 'Flujos de autenticación sin estado, refresh tokens rotativos, control de acceso por roles (RBAC) y protección frente a abusos.',
      level: 'Sólido',
      projects: 'Telemetry Hub, Plataforma Modular'
    },
    postgres: {
      badge: 'L3 · DATOS & CACHÉ',
      title: 'PostgreSQL & Modelado ACID',
      desc: 'Diseño relacional normalizado, índices optimizados, transacciones seguras, migraciones versionadas y consultas analíticas.',
      level: 'Avanzado',
      projects: 'Telemetry Hub'
    },
    'redis-cache': {
      badge: 'L3 · DATOS & CACHÉ',
      title: 'Redis Cache & MongoDB',
      desc: 'Caché en memoria sub-milisegundo, rate limiting, colas pub/sub y persistencia documental flexible en NoSQL.',
      level: 'Sólido',
      projects: 'Telemetry Hub, Cluster Orchestrator'
    },
    'git-actions': {
      badge: 'L4 · CLOUD & DEVOPS',
      title: 'Git & GitHub Actions CI/CD',
      desc: 'Automatización de flujos de prueba, linting, generación diaria de feeds JSON y despliegue automático en GitHub Pages.',
      level: 'Avanzado',
      projects: 'Portfolio 3D, Pipelines CI/CD'
    },
    'linux-nginx': {
      badge: 'L4 · CLOUD & DEVOPS',
      title: 'Linux, Nginx & Cloud',
      desc: 'Administración de servidores Linux, proxy inverso, certificados TLS, scripts Bash y monitorización de servicios.',
      level: 'Sólido',
      projects: 'Cloud Cluster Orchestrator'
    },
    'hub-portfolio-3d': {
      badge: '★ TRANSBORDO L1 + L4',
      title: 'Proyecto: Explorador PC 3D',
      desc: 'Estación de enlace donde WebGL/Three.js converge con automatización en GitHub Pages, datos en vivo y diseño adaptativo.',
      level: 'Producción',
      projects: 'Three.js + ES6 + Actions'
    },
    'hub-telemetry': {
      badge: '★ TRANSBORDO L1 + L2',
      title: 'Proyecto: Telemetry Hub UI + API',
      desc: 'Conexión en tiempo real entre paneles frontend reactivos y endpoints REST/WebSocket de baja latencia.',
      level: 'Producción',
      projects: 'React + Node.js + REST'
    },
    'hub-api-data': {
      badge: '★ TRANSBORDO L2 + L3',
      title: 'Núcleo: Auth & Persistencia ACID',
      desc: 'Integración crítica entre lógica de servidor Node.js, validación de sesiones JWT, caché en Redis y PostgreSQL.',
      level: 'Producción',
      projects: 'Telemetry & Auth API Hub'
    },
    'hub-cloud-orchestrator': {
      badge: '★ TRANSBORDO L3 + L4',
      title: 'Proyecto: Cloud Docker Cluster',
      desc: 'Contenerización reproducible de bases de datos, cachés y microservicios con volúmenes aislados y despliegue sin caídas.',
      level: 'Producción',
      projects: 'Cloud Cluster Orchestrator'
    },
    'hub-cicd-scale': {
      badge: '★ TRANSBORDO L2 + L4',
      title: 'Arquitectura: Auto-Scale & CI/CD',
      desc: 'Escalamiento horizontal de servicios backend mediante pipelines automatizados, healthchecks y balanceo de carga.',
      level: 'Producción',
      projects: 'Cloud Cluster Orchestrator'
    }
  };

  function initMetroMap() {
    const stations = document.querySelectorAll('.metro-station');
    const lines = document.querySelectorAll('.metro-line');
    const filterBtns = document.querySelectorAll('.metro-filter-btn');

    const selectStation = (stationEl) => {
      const key = stationEl.getAttribute('data-station');
      const info = METRO_STATIONS[key];
      if (!info) return;

      stations.forEach((s) => s.classList.remove('active'));
      stationEl.classList.add('active');

      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
      };
      setTxt('metro-detail-badge', info.badge);
      setTxt('metro-detail-title', info.title);
      setTxt('metro-detail-desc', info.desc);
      setTxt('metro-detail-level', info.level);
      setTxt('metro-detail-projects', info.projects);
    };

    stations.forEach((st) => {
      st.addEventListener('click', () => selectStation(st));
      st.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          selectStation(st);
        }
      });
    });

    filterBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        const lineKey = btn.getAttribute('data-line');
        filterBtns.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');

        if (lineKey === 'all') {
          lines.forEach((l) => l.classList.remove('is-dimmed'));
          stations.forEach((s) => s.classList.remove('is-dimmed'));
          return;
        }

        lines.forEach((l) => {
          l.classList.toggle('is-dimmed', l.getAttribute('data-line') !== lineKey);
        });
        stations.forEach((s) => {
          const stLines = (s.getAttribute('data-lines') || '').split(' ');
          s.classList.toggle('is-dimmed', !stLines.includes(lineKey));
        });
      });
    });
  }
  initMetroMap();

  // ==========================================================================
  // 5. DEMOS VIVAS EN PROYECTOS (API SANDBOX & DOCKER ORCHESTRATOR)
  // ==========================================================================
  function initLiveProjectDemos() {
    // Switcher Vista Demos Vivas vs VS Code IDE
    const btnDemos = document.getElementById('btn-view-demos');
    const btnVscode = document.getElementById('btn-view-vscode');
    const demosView = document.getElementById('projects-demos-view');
    const vscodeView = document.getElementById('projects-vscode-view');

    function setProjectsView(mode) {
      const isIde = mode === 'vscode';
      if (btnDemos) {
        btnDemos.classList.toggle('active', !isIde);
        btnDemos.setAttribute('aria-selected', String(!isIde));
      }
      if (btnVscode) {
        btnVscode.classList.toggle('active', isIde);
        btnVscode.setAttribute('aria-selected', String(isIde));
      }
      if (demosView) demosView.classList.toggle('is-hidden', isIde);
      if (vscodeView) vscodeView.classList.toggle('is-hidden', !isIde);
    }

    if (btnDemos) btnDemos.addEventListener('click', () => setProjectsView('demos'));
    if (btnVscode) btnVscode.addEventListener('click', () => setProjectsView('vscode'));

    // Demo 2: API & Telemetry Sandbox
    const epBtns = document.querySelectorAll('.ep-btn[data-endpoint]');
    const apiSendBtn = document.getElementById('demo-api-send');
    const apiShortcutBtn = document.getElementById('btn-run-api-shortcut');
    const apiStatus = document.getElementById('demo-api-status');
    const apiLatency = document.getElementById('demo-api-latency');
    const apiOutput = document.getElementById('demo-api-output');

    epBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        epBtns.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        appState.selectedEndpoint = btn.getAttribute('data-endpoint');
      });
    });

    function runApiSimulation() {
      if (!apiOutput) return;
      if (apiStatus) apiStatus.textContent = 'LOADING...';
      const simulatedMs = Math.round(14 + Math.random() * 32);

      setTimeout(() => {
        let code = '200 OK';
        let payload = {};
        if (appState.selectedEndpoint === '/api/metrics') {
          payload = {
            status: 'ok',
            cache_hit: true,
            rps: Math.round(1240 + Math.random() * 380),
            p95_ms: simulatedMs,
            active_connections: Math.round(42 + Math.random() * 18)
          };
        } else if (appState.selectedEndpoint === '/api/auth') {
          code = '201 CREATED';
          payload = {
            authenticated: true,
            role: appState.persona,
            token_type: 'Bearer JWT',
            expires_in: 900,
            token_preview: 'eyJhbGciOiJIUzI1NiIsInR5cCI6...'
          };
        } else {
          payload = {
            service: 'telemetry-api-hub',
            postgres: 'connected (ACID)',
            redis: 'pong (0.4ms)',
            uptime_sec: Math.round(performance.now() / 1000) + 86400
          };
        }

        if (apiStatus) apiStatus.textContent = code;
        if (apiLatency) apiLatency.textContent = `Latencia: ${simulatedMs} ms`;
        apiOutput.textContent = JSON.stringify(payload, null, 2);
      }, 150);
    }

    if (apiSendBtn) apiSendBtn.addEventListener('click', runApiSimulation);
    if (apiShortcutBtn) apiShortcutBtn.addEventListener('click', runApiSimulation);

    // Demo 3: Cloud Cluster Orchestrator
    const addNodeBtn = document.getElementById('demo-node-add');
    const removeNodeBtn = document.getElementById('demo-node-remove');
    const spikeBtn = document.getElementById('demo-traffic-spike');
    const spikeShortcutBtn = document.getElementById('btn-scale-cluster-shortcut');
    const containersGrid = document.getElementById('demo-containers-grid');
    const clusterSummary = document.getElementById('demo-cluster-summary');

    function renderPods() {
      if (!containersGrid) return;
      const totalLoad = appState.trafficSpike ? 168 : 66;
      const perPodLoad = Math.min(96, Math.round(totalLoad / appState.pods.length));

      containersGrid.innerHTML = appState.pods
        .map((pod, idx) => {
          const load = Math.min(98, Math.max(8, perPodLoad + ((idx % 2 === 0 ? 4 : -4))));
          const isHot = load > 72;
          return `<div class="pod-pill ${isHot ? 'is-hot' : ''}">
            <span>${pod.id}</span>
            <strong>${load}% CPU</strong>
          </div>`;
        })
        .join('');

      if (clusterSummary) {
        const reqSec = appState.trafficSpike ? 2840 : 720;
        clusterSummary.textContent = `${appState.pods.length} Pods · ${perPodLoad}% CPU · ${reqSec} req/s`;
      }
    }

    if (addNodeBtn) {
      addNodeBtn.addEventListener('click', () => {
        if (appState.pods.length >= 6) {
          showToast('Límite del Clúster', 'Máximo de 6 contenedores simultáneos en esta demo.');
          return;
        }
        const num = String(appState.pods.length).padStart(2, '0');
        appState.pods.push({ id: `worker-${num}`, cpu: 20 });
        renderPods();
      });
    }

    if (removeNodeBtn) {
      removeNodeBtn.addEventListener('click', () => {
        if (appState.pods.length <= 2) {
          showToast('Alta Disponibilidad', 'Se requieren al menos 2 nodos activos para HA.');
          return;
        }
        appState.pods.pop();
        renderPods();
      });
    }

    const triggerTrafficSpike = () => {
      appState.trafficSpike = !appState.trafficSpike;
      if (spikeBtn) {
        spikeBtn.textContent = appState.trafficSpike ? '✅ Normalizar Tráfico' : '⚡ Pico Tráfico';
      }
      renderPods();
    };

    if (spikeBtn) spikeBtn.addEventListener('click', triggerTrafficSpike);
    if (spikeShortcutBtn) spikeShortcutBtn.addEventListener('click', triggerTrafficSpike);
    renderPods();
  }
  initLiveProjectDemos();

  // ==========================================================================
  // 6. EDITOR DE CÓDIGO ESTILO VS CODE (IDE)
  // ==========================================================================
  const VSCODE_FILES = {
    'about.md': {
      lang: 'Markdown',
      content: [
        '# Rafa · Desarrollador Full-Stack & Creative Engineer',
        '',
        '## Filosofía de Ingeniería',
        '- **Arquitectura limpia**: separación estricta de responsabilidades.',
        '- **Rendimiento medido**: 60 FPS en WebGL, carga estática en GitHub Pages.',
        '- **Accesibilidad real**: navegación por teclado + Modo CV Clásico.',
        '',
        '## Enfoque Actual',
        'Construyendo interfaces interactivas 3D con Three.js,',
        'APIs asíncronas en Node.js / Python y despliegues en Docker.'
      ].join('\n')
    },
    'projects.json': {
      lang: 'JSON',
      content: JSON.stringify(
        {
          portfolio: 'Rafa.dev 3D Workstation',
          projects: [
            {
              id: 'pc-3d-explorer',
              problem: 'Portfolios planos que no demuestran ingeniería real',
              solution: 'Motor 3D procedimental sin .glb con raycasting y shaders',
              stack: ['Three.js', 'WebGL', 'ES6+', 'CSS3']
            },
            {
              id: 'telemetry-auth-hub',
              problem: 'Picos de latencia SQL y sesiones distribuidas',
              solution: 'API REST Node.js + caché Redis + JWT rotativo + PostgreSQL',
              stack: ['Node.js', 'PostgreSQL', 'Redis', 'JWT']
            },
            {
              id: 'cloud-cluster-orchestrator',
              problem: 'Despliegues monolíticos con tiempo de inactividad',
              solution: 'Microservicios Docker con auto-escalado y CI/CD',
              stack: ['React', 'Docker', 'GitHub Actions', 'Linux']
            }
          ]
        },
        null,
        2
      )
    },
    'skills.ts': {
      lang: 'TypeScript',
      content: [
        'interface TechStack {',
        '  frontend: string[];',
        '  backend: string[];',
        '  dataAndCloud: string[];',
        '}',
        '',
        'export const rafaStack: TechStack = {',
        '  frontend: ["HTML5", "CSS3", "TypeScript", "React", "Three.js", "WebGL"],',
        '  backend: ["Node.js", "Python FastAPI", "Java OOP", "REST", "GraphQL"],',
        '  dataAndCloud: ["PostgreSQL", "Redis", "MongoDB", "Docker", "GitHub Actions"]',
        '};',
        '',
        'export function getReadiness(): string {',
        '  return "100% Operativo para nuevos proyectos y equipos.";',
        '}'
      ].join('\n')
    },
    'architecture.md': {
      lang: 'Markdown',
      content: [
        '# Arquitectura del Portfolio',
        '',
        '> Decisiones clave para destacar en GitHub Pages sin backend propietario.',
        '',
        '1. **Zero-Build Static Hosting**: HTML + CSS + JS nativos.',
        '2. **Motor 3D Procedimental (`pc3d.js`)**: 0 modelos pesados descargados.',
        '3. **Datos Vivos**: GitHub Public REST API con caché en `sessionStorage`.',
        '4. **Multi-Formato**: 3D, Terminal zsh, VS Code IDE, Mapa Metro y CV Clásico.'
      ].join('\n')
    },
    'lighthouse.json': {
      lang: 'JSON',
      content: JSON.stringify(
        {
          target: 'GitHub Pages Static Deployment',
          scores: {
            performance: 98,
            accessibility: 100,
            bestPractices: 100,
            seo: 100
          },
          optimizations: [
            'Procedural geometry instead of large .glb assets',
            'Pixel ratio capped at 1.5 on mobile + Eco Mode toggle',
            'Pause WebGL loop automatically in Classic CV view'
          ]
        },
        null,
        2
      )
    }
  };

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function highlightSyntax(code, lang) {
    let escaped = escapeHtml(code);
    if (lang === 'JSON') {
      escaped = escaped
        .replace(/(&quot;|")([^"\n]+)(&quot;|")\s*:/g, '<span class="tok-key">"$2"</span>:')
        .replace(/:\s*"([^"\n]*)"/g, ': <span class="tok-str">"$1"</span>')
        .replace(/\b(\d+)\b/g, '<span class="tok-num">$1</span>');
      return escaped;
    }
    if (lang === 'TypeScript') {
      escaped = escaped
        .replace(/(\/\/[^\n]*)/g, '<span class="tok-com">$1</span>')
        .replace(/\b(interface|export|const|function|return|string)\b/g, '<span class="tok-kw">$1</span>')
        .replace(/\b(TechStack)\b/g, '<span class="tok-type">$1</span>')
        .replace(/"([^"\n]*)"/g, '<span class="tok-str">"$1"</span>');
      return escaped;
    }
    // Markdown highlight
    return escaped
      .replace(/^(#{1,3}\s+.*)$/gm, '<span class="tok-key">$1</span>')
      .replace(/^(&gt;\s+.*)$/gm, '<span class="tok-com">$1</span>')
      .replace(/\*\*([^*]+)\*\*/g, '<span class="tok-kw">**$1**</span>')
      .replace(/`([^`]+)`/g, '<span class="tok-str">`$1`</span>');
  }

  function parseSimpleMarkdown(md) {
    const lines = md.split('\n');
    let html = '';
    let inList = false;

    const formatInline = (txt) =>
      escapeHtml(txt)
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        .replace(/`([^`]+)`/g, '<code>$1</code>');

    lines.forEach((rawLine) => {
      const line = rawLine.trim();
      if (!line) {
        if (inList) {
          html += '</ul>';
          inList = false;
        }
        return;
      }
      if (line.startsWith('- ') || /^\d+\.\s/.test(line)) {
        if (!inList) {
          html += '<ul>';
          inList = true;
        }
        const item = line.replace(/^(-\s+|\d+\.\s+)/, '');
        html += `<li>${formatInline(item)}</li>`;
        return;
      }
      if (inList) {
        html += '</ul>';
        inList = false;
      }
      if (line.startsWith('### ')) {
        html += `<h4>${formatInline(line.slice(4))}</h4>`;
      } else if (line.startsWith('## ')) {
        html += `<h4>${formatInline(line.slice(3))}</h4>`;
      } else if (line.startsWith('# ')) {
        html += `<h3>${formatInline(line.slice(2))}</h3>`;
      } else if (line.startsWith('> ')) {
        html += `<blockquote>${formatInline(line.slice(2))}</blockquote>`;
      } else {
        html += `<p>${formatInline(line)}</p>`;
      }
    });

    if (inList) html += '</ul>';
    return html;
  }

  function initVSCodeEditor() {
    const fileBtns = document.querySelectorAll('.vscode-file-btn[data-file]');
    const tabBtns = document.querySelectorAll('.vscode-tab[data-file]');
    const lineNumsEl = document.getElementById('vscode-line-numbers');
    const codeAreaEl = document.getElementById('vscode-code-area');
    const langStatusEl = document.getElementById('vscode-lang-status');
    const runBtn = document.getElementById('vscode-run-btn');
    const previewPanel = document.getElementById('vscode-preview-panel');
    const previewBody = document.getElementById('vscode-preview-body');
    const closePreviewBtn = document.getElementById('vscode-close-preview');

    let activeFile = 'about.md';

    function openFile(fileName) {
      const file = VSCODE_FILES[fileName];
      if (!file || !codeAreaEl || !lineNumsEl) return;
      activeFile = fileName;

      fileBtns.forEach((b) => b.classList.toggle('active', b.getAttribute('data-file') === fileName));
      tabBtns.forEach((t) => t.classList.toggle('active', t.getAttribute('data-file') === fileName));

      const lineCount = file.content.split('\n').length;
      lineNumsEl.innerHTML = Array.from({ length: lineCount }, (_, i) => i + 1).join('<br>');
      codeAreaEl.innerHTML = highlightSyntax(file.content, file.lang);
      if (langStatusEl) langStatusEl.textContent = file.lang;
    }

    fileBtns.forEach((b) => b.addEventListener('click', () => openFile(b.getAttribute('data-file'))));
    tabBtns.forEach((t) => t.addEventListener('click', () => openFile(t.getAttribute('data-file'))));

    if (runBtn && previewPanel && previewBody) {
      runBtn.addEventListener('click', () => {
        const file = VSCODE_FILES[activeFile];
        if (!file) return;
        previewPanel.classList.remove('is-hidden');
        if (file.lang === 'Markdown') {
          previewBody.innerHTML = parseSimpleMarkdown(file.content);
        } else if (file.lang === 'JSON') {
          const parsed = JSON.parse(file.content);
          previewBody.innerHTML = `<p>✅ JSON válido (${Object.keys(parsed).length} claves raíz). Listo para consumo en producción.</p>`;
        } else {
          previewBody.innerHTML = '<p>▶ Compilación TypeScript simulada: <strong>0 errores</strong>. Salida: <code>"100% Operativo para nuevos proyectos y equipos."</code></p>';
        }
      });
    }

    if (closePreviewBtn && previewPanel) {
      closePreviewBtn.addEventListener('click', () => previewPanel.classList.add('is-hidden'));
    }

    openFile('about.md');
  }
  initVSCodeEditor();

  // ==========================================================================
  // 7. PANEL DE ACTIVIDAD GITHUB EN VIVO (@Rafags04)
  // ==========================================================================
  const GH_FALLBACK = {
    user: {
      login: 'Rafags04',
      name: 'Rafa',
      avatar_url: 'https://github.com/Rafags04.png',
      bio: 'Desarrollador de Software Full-Stack · WebGL 3D, APIs & Cloud.',
      public_repos: 12,
      followers: 8
    },
    repos: [
      {
        name: 'PortFolio',
        description: 'Portfolio interactivo 3D en Three.js con raycasting, IDE VS Code y terminal.',
        language: 'JavaScript',
        stargazers_count: 5,
        updated_at: '2026-11-16T09:00:00Z',
        html_url: 'https://github.com/Rafags04/PortFolio'
      },
      {
        name: 'telemetry-api-hub',
        description: 'API REST asíncrona con Node.js, PostgreSQL, Redis cache y autenticación JWT.',
        language: 'TypeScript',
        stargazers_count: 3,
        updated_at: '2026-10-12T12:00:00Z',
        html_url: 'https://github.com/Rafags04'
      },
      {
        name: 'cloud-cluster-orchestrator',
        description: 'Arquitectura modular en Docker con balanceo dinámico y CI/CD.',
        language: 'Python',
        stargazers_count: 2,
        updated_at: '2026-09-20T15:00:00Z',
        html_url: 'https://github.com/Rafags04'
      },
      {
        name: 'algorithms-java-lab',
        description: 'Estructuras de datos, patrones de diseño y utilidades OOP en Java.',
        language: 'Java',
        stargazers_count: 2,
        updated_at: '2026-08-05T10:00:00Z',
        html_url: 'https://github.com/Rafags04'
      }
    ]
  };

  const LANG_COLORS = {
    JavaScript: '#facc15',
    TypeScript: '#38bdf8',
    HTML: '#fb7185',
    CSS: '#a855f7',
    Python: '#34d399',
    Java: '#f97316',
    Shell: '#94a3b8'
  };

  function renderGitHubData(user, repos, sourceLabel) {
    appState.githubData = { user, repos, sourceLabel };

    const avatarEl = document.getElementById('gh-avatar');
    const nameEl = document.getElementById('gh-name');
    const bioEl = document.getElementById('gh-bio');
    const statusEl = document.getElementById('gh-api-status');
    const reposCountEl = document.getElementById('gh-repos-count');
    const followersEl = document.getElementById('gh-followers-count');
    const starsEl = document.getElementById('gh-stars-count');
    const langBarEl = document.getElementById('gh-lang-bar');
    const langLegendEl = document.getElementById('gh-lang-legend');
    const reposGridEl = document.getElementById('gh-repos-grid');

    if (avatarEl && user.avatar_url) avatarEl.src = user.avatar_url;
    if (nameEl) nameEl.textContent = `${user.name || user.login} (@${user.login})`;
    if (bioEl) bioEl.textContent = user.bio || 'Desarrollador Full-Stack & Creative Engineer en GitHub.';
    if (statusEl) statusEl.textContent = sourceLabel;
    if (reposCountEl) reposCountEl.textContent = String(user.public_repos ?? repos.length);
    if (followersEl) followersEl.textContent = String(user.followers ?? 0);

    const totalStars = repos.reduce((acc, r) => acc + (r.stargazers_count || 0), 0);
    if (starsEl) starsEl.textContent = String(totalStars);

    // Distribución de lenguajes
    const langCounts = {};
    repos.forEach((r) => {
      if (r.language) {
        langCounts[r.language] = (langCounts[r.language] || 0) + 1;
      }
    });
    const totalWithLang = Object.values(langCounts).reduce((a, b) => a + b, 0) || 1;
    const sortedLangs = Object.entries(langCounts).sort((a, b) => b[1] - a[1]);

    if (langBarEl && langLegendEl) {
      langBarEl.innerHTML = sortedLangs
        .map(([lang, count]) => {
          const pct = ((count / totalWithLang) * 100).toFixed(1);
          const col = LANG_COLORS[lang] || '#00f0ff';
          return `<div class="gh-lang-seg" style="width:${pct}%;background:${col}" title="${lang}: ${pct}%"></div>`;
        })
        .join('');

      langLegendEl.innerHTML = sortedLangs
        .map(([lang, count]) => {
          const pct = Math.round((count / totalWithLang) * 100);
          const col = LANG_COLORS[lang] || '#00f0ff';
          return `<span class="gh-lang-item"><span class="gh-lang-dot" style="background:${col}"></span>${lang} ${pct}%</span>`;
        })
        .join('');
    }

    if (reposGridEl) {
      reposGridEl.innerHTML = repos
        .slice(0, 4)
        .map((repo) => {
          const dateStr = repo.updated_at ? repo.updated_at.slice(0, 10) : 'Reciente';
          const lang = repo.language || 'Code';
          const desc = escapeHtml(repo.description || 'Repositorio de ingeniería y código fuente.');
          return `<a href="${repo.html_url}" target="_blank" rel="noopener noreferrer" class="gh-repo-card">
            <strong>${escapeHtml(repo.name)}</strong>
            <p>${desc}</p>
            <div class="gh-repo-meta">
              <span>${escapeHtml(lang)}</span>
              <span>★ ${repo.stargazers_count || 0} · ${dateStr}</span>
            </div>
          </a>`;
        })
        .join('');
    }
  }

  async function loadGitHubLive(forceRefresh = false) {
    const cacheKey = 'rafa_gh_cache_v1';
    const ttlMs = 15 * 60 * 1000;

    if (!forceRefresh) {
      try {
        const raw = sessionStorage.getItem(cacheKey);
        if (raw) {
          const cached = JSON.parse(raw);
          if (Date.now() - cached.ts < ttlMs && cached.user && cached.repos) {
            renderGitHubData(cached.user, cached.repos, 'Caché de Sesión');
            return;
          }
        }
      } catch (_) {
        // Ignorar errores de almacenamiento
      }
    }

    try {
      const [userRes, reposRes] = await Promise.all([
        fetch('https://api.github.com/users/Rafags04'),
        fetch('https://api.github.com/users/Rafags04/repos?sort=updated&per_page=8')
      ]);

      if (!userRes.ok || !reposRes.ok) {
        throw new Error(`HTTP ${userRes.status}`);
      }

      const user = await userRes.json();
      const repos = await reposRes.json();

      try {
        sessionStorage.setItem(cacheKey, JSON.stringify({ ts: Date.now(), user, repos }));
      } catch (_) {
        // Ignorar cuota de almacenamiento
      }

      renderGitHubData(user, repos, 'GitHub API en Vivo');
    } catch (_) {
      renderGitHubData(GH_FALLBACK.user, GH_FALLBACK.repos, 'Respaldo Local');
    }
  }

  const refreshGhBtn = document.getElementById('btn-refresh-github');
  if (refreshGhBtn) {
    refreshGhBtn.addEventListener('click', () => loadGitHubLive(true));
  }
  loadGitHubLive(false);

  // ==========================================================================
  // 8. "TU WEB COMO PROYECTO EN SÍ", AUDITORÍA DOM & MINI-BLOG MARKDOWN
  // ==========================================================================
  const BLOG_POSTS = {
    post1: [
      '# 01. Despiece 3D en Three.js sin modelos .glb externos',
      '',
      'Descargar mallas 3D pesadas suele penalizar el tiempo de carga inicial en **GitHub Pages**.',
      '',
      '### Qué hice en su lugar',
      '- Modelé cada pieza por código en `pc3d.js`: chasis, cristal templado, GPU con 35 aletas, bomba AIO y SSD NVMe.',
      '- Generé las texturas PCB y la pantalla OLED en vivo usando **Canvas 2D** en memoria.',
      '- El motor completo pesa menos de 65 KB sin compresión y arranca casi al instante.'
    ].join('\n'),
    post2: [
      '# 02. Raycasting 3D detrás de tarjetas Glassmorphic',
      '',
      'Hacer clic en componentes 3D cuando hay contenido HTML delante exige separar bien qué capa captura cada evento.',
      '',
      '### Solución aplicada',
      '- `.story-wrapper` usa `pointer-events: none` mientras cada tarjeta reactiva `.glass-card` usa `pointer-events: auto`.',
      '- El `THREE.Raycaster` solo dispara hover cuando `e.target === canvas` y distingue clic de arrastre si el movimiento es menor de `6px`.',
      '- Resultado: puedes rotar la cámara o hacer clic directo sobre la GPU o la CPU sin conflictos.'
    ].join('\n'),
    post3: [
      '# 03. Automatizando la sección "Ahora mismo" con GitHub Actions',
      '',
      'Un portfolio estático puede mantenerse vivo sin servidor backend propietario.',
      '',
      '### Flujo recomendado',
      '- Un cron diario en `.github/workflows/daily-status.yml` consulta APIs públicas (como Last.fm o lecturas) y genera `daily-status.json`.',
      '- La web estática lee ese JSON y la API pública de GitHub en cada visita.',
      '- Cero costes de servidor y actividad técnica demostrable cada semana.'
    ].join('\n')
  };

  function initMetaAndBlog() {
    const tabBtns = document.querySelectorAll('.meta-tab-btn[data-meta-tab]');
    const tabPanels = document.querySelectorAll('.meta-tab-panel[data-meta-panel]');

    tabBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-meta-tab');
        tabBtns.forEach((b) => {
          const active = b === btn;
          b.classList.toggle('active', active);
          b.setAttribute('aria-selected', String(active));
        });
        tabPanels.forEach((panel) => {
          panel.classList.toggle('active', panel.getAttribute('data-meta-panel') === key);
        });
      });
    });

    // Mini-Blog Markdown
    const postBtns = document.querySelectorAll('.md-post-btn[data-post]');
    const toggleSourceBtn = document.getElementById('btn-toggle-md-source');
    const renderedEl = document.getElementById('md-blog-rendered');
    const rawEl = document.getElementById('md-blog-raw');
    let showSource = false;

    function loadBlogPost(postKey) {
      const md = BLOG_POSTS[postKey];
      if (!md || !renderedEl || !rawEl) return;
      postBtns.forEach((b) => b.classList.toggle('active', b.getAttribute('data-post') === postKey));
      renderedEl.innerHTML = parseSimpleMarkdown(md);
      rawEl.textContent = md;
    }

    postBtns.forEach((b) => b.addEventListener('click', () => loadBlogPost(b.getAttribute('data-post'))));

    if (toggleSourceBtn && renderedEl && rawEl) {
      toggleSourceBtn.addEventListener('click', () => {
        showSource = !showSource;
        renderedEl.classList.toggle('is-hidden', showSource);
        rawEl.classList.toggle('is-hidden', !showSource);
        toggleSourceBtn.textContent = showSource ? 'Ver renderizado HTML' : 'Ver fuente .md';
      });
    }
    loadBlogPost('post1');

    // Auditoría DOM en tiempo real
    const auditBtn = document.getElementById('btn-run-self-audit');
    const auditReport = document.getElementById('self-audit-report');
    if (auditBtn && auditReport) {
      auditBtn.addEventListener('click', () => {
        const domNodes = document.querySelectorAll('*').length;
        const interactiveCtrls = document.querySelectorAll('a, button, input').length;
        const ariaAttrs = document.querySelectorAll('[aria-label], [aria-labelledby], [role]').length;
        const webglOk = Boolean(window.pcViewer && window.pcViewer.renderer);
        auditReport.innerHTML = [
          `✔ <strong>Nodos DOM:</strong> ${domNodes} elementos · <strong>Controles:</strong> ${interactiveCtrls}`,
          `✔ <strong>Accesibilidad:</strong> ${ariaAttrs} atributos ARIA/Roles detectados`,
          `✔ <strong>Motor WebGL:</strong> ${webglOk ? 'Activo (PBR + Raycaster)' : 'Fallback 2D'} · <strong>Eco Mode:</strong> ${appState.ecoMode ? 'ON' : 'OFF'}`
        ].join('<br>');
      });
    }
  }
  initMetaAndBlog();

  // ==========================================================================
  // 9. TERMINAL INTERACTIVA (rafa@portfolio:~)
  // ==========================================================================
  function initInteractiveTerminal() {
    const outputEl = document.getElementById('terminal-output');
    const formEl = document.getElementById('terminal-form');
    const inputEl = document.getElementById('terminal-input');
    const quickChips = document.querySelectorAll('.term-chip[data-cmd]');
    const openTermBtn = document.getElementById('btn-open-terminal');

    if (!outputEl || !formEl || !inputEl) return;

    const history = [];
    let historyIdx = -1;
    const COMMAND_LIST = [
      'help', 'about', 'skills', 'projects', 'github', 'contact',
      'cv', 'persona', 'theme', 'overclock', 'matrix', 'neofetch', 'sudo', 'clear'
    ];

    function printLine(text, type = 'info') {
      const div = document.createElement('div');
      div.className = `term-line ${type}`;
      div.textContent = text;
      outputEl.appendChild(div);
      outputEl.scrollTop = outputEl.scrollHeight;
    }

    function printBootBanner() {
      printLine('Rafa.dev Workstation OS v2.6 · Interactive Shell', 'accent');
      printLine("Escribe 'help' para listar comandos o pulsa cualquier chip superior.", 'info');
    }
    printBootBanner();

    function executeCommand(rawCmd) {
      const cmdLine = rawCmd.trim();
      if (!cmdLine) return;

      history.unshift(cmdLine);
      historyIdx = -1;
      printLine(`rafa@portfolio:~$ ${cmdLine}`, 'cmd');

      const parts = cmdLine.toLowerCase().split(/\s+/);
      const cmd = parts[0];
      const arg = parts[1];

      if (cmd === 'clear') {
        outputEl.innerHTML = '';
        return;
      }

      if (cmd === 'help') {
        printLine('Comandos disponibles:', 'accent');
        printLine('  about                     -> Resumen del perfil de Rafa');
        printLine('  skills                    -> Stack técnico Frontend, Backend & Cloud');
        printLine('  projects                  -> Proyectos con problema, solución y demos');
        printLine('  github                    -> Resumen de la actividad en @Rafags04');
        printLine('  contact                   -> Enlaces de contacto directo');
        printLine('  cv                        -> Abrir Modo CV Clásico imprimible');
        printLine('  persona <recruiter|dev|client> -> Adaptar portfolio al visitante');
        printLine('  theme <cyber|neon|matrix|solar|stealth> -> Cambiar RGB 3D');
        printLine('  overclock                 -> Alternar modo Overclock en ventiladores 3D');
        printLine('  matrix                    -> Alternar lluvia Matrix en canvas');
        printLine('  neofetch                  -> Especificaciones del sistema 3D');
        printLine('  sudo hire rafa            -> Comando especial para reclutadores');
        return;
      }

      if (cmd === 'about') {
        printLine('Rafa · Desarrollador Full-Stack & Creative Engineer.', 'success');
        printLine('Especializado en arquitectura limpia, APIs escalables y experiencias WebGL 3D.');
        return;
      }

      if (cmd === 'skills') {
        printLine('[Frontend]  HTML5, CSS3, TypeScript, React/Next.js, Three.js, WebGL', 'accent');
        printLine('[Backend]   Node.js, Python FastAPI, Java OOP, REST, GraphQL, JWT/OAuth', 'info');
        printLine('[Datos/Ops] PostgreSQL, MongoDB, Redis, Docker, GitHub Actions, Linux', 'success');
        return;
      }

      if (cmd === 'projects') {
        printLine('1) Explorador PC 3D & Despiece (Three.js + Raycasting + Bloom)', 'accent');
        printLine('2) Telemetry & Auth API Hub (Node.js + PostgreSQL + Redis + JWT)', 'info');
        printLine('3) Cloud Cluster Orchestrator (React + Docker + Microservicios)', 'success');
        return;
      }

      if (cmd === 'github') {
        const gh = appState.githubData;
        if (gh) {
          printLine(`@${gh.user.login} · Repos públicos: ${gh.user.public_repos} · Origen: ${gh.sourceLabel}`, 'success');
          gh.repos.slice(0, 3).forEach((r) => {
            printLine(`  • ${r.name} [${r.language || 'Code'}] ★ ${r.stargazers_count || 0}`);
          });
        } else {
          printLine('GitHub: https://github.com/Rafags04', 'info');
        }
        return;
      }

      if (cmd === 'contact') {
        printLine('Email:    tu-correo@ejemplo.com', 'accent');
        printLine('GitHub:   https://github.com/Rafags04', 'info');
        printLine('Estado:   Disponible para nuevas oportunidades.', 'success');
        return;
      }

      if (cmd === 'cv') {
        printLine('Abriendo Modo CV Clásico...', 'success');
        openClassicCV();
        return;
      }

      if (cmd === 'persona') {
        const map = { reclutador: 'recruiter', recruiter: 'recruiter', dev: 'developer', desarrollador: 'developer', developer: 'developer', cliente: 'client', client: 'client' };
        const resolved = map[arg];
        if (!resolved) {
          printLine('Uso: persona <reclutador|dev|cliente>', 'warn');
        } else {
          setVisitorPersona(resolved);
          printLine(`Portfolio adaptado al perfil: ${resolved}`, 'success');
        }
        return;
      }

      if (cmd === 'theme') {
        if (['cyber', 'neon', 'matrix', 'solar', 'stealth'].includes(arg)) {
          applyTheme(arg);
          printLine(`Iluminación RGB cambiada a: ${arg}`, 'success');
        } else {
          printLine('Temas válidos: cyber, neon, matrix, solar, stealth', 'warn');
        }
        return;
      }

      if (cmd === 'overclock') {
        setOverclock(!appState.overclock);
        printLine(`Modo Overclock 6.2GHz: ${appState.overclock ? 'ACTIVADO' : 'DESACTIVADO'}`, appState.overclock ? 'warn' : 'info');
        return;
      }

      if (cmd === 'matrix') {
        setMatrixRain(!appState.matrixRain);
        printLine(`Modo Matrix: ${appState.matrixRain ? 'ACTIVADO' : 'DESACTIVADO'}`, 'success');
        return;
      }

      if (cmd === 'neofetch') {
        printLine('       /\\        rafa@portfolio', 'accent');
        printLine('      /  \\       --------------', 'accent');
        printLine('     / /\\ \\      Engine: Three.js r128 PBR + Raycaster', 'info');
        printLine('    / ____ \\     CPU:    16-Core @ ' + (appState.overclock ? '6.2 GHz (OC)' : '5.4 GHz'), 'info');
        printLine('   /_/    \\_\\    GPU:    RTX 24GB GDDR6X // WebGL', 'info');
        printLine(`                 Perfil: ${appState.persona} | Eco: ${appState.ecoMode}`, 'success');
        return;
      }

      if (cmdLine.toLowerCase() === 'sudo hire rafa') {
        printLine('[sudo] password for visitor: ********', 'warn');
        printLine('✔ Acceso concedido. ¡Gracias por visitar! Conectando con Rafa...', 'success');
        showToast('sudo hire rafa', '¡Solicitud de fichaje registrada! Usa las tarjetas de contacto.');
        return;
      }

      printLine(`Comando no reconocido: '${cmd}'. Escribe 'help' para ver opciones.`, 'error');
    }

    formEl.addEventListener('submit', (e) => {
      e.preventDefault();
      executeCommand(inputEl.value);
      inputEl.value = '';
    });

    inputEl.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (historyIdx < history.length - 1) {
          historyIdx++;
          inputEl.value = history[historyIdx];
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (historyIdx > 0) {
          historyIdx--;
          inputEl.value = history[historyIdx];
        } else {
          historyIdx = -1;
          inputEl.value = '';
        }
      } else if (e.key === 'Tab') {
        e.preventDefault();
        const val = inputEl.value.trim().toLowerCase();
        const match = COMMAND_LIST.find((c) => c.startsWith(val));
        if (match) inputEl.value = match;
      }
    });

    quickChips.forEach((chip) => {
      chip.addEventListener('click', () => {
        executeCommand(chip.getAttribute('data-cmd'));
        inputEl.focus();
      });
    });

    if (openTermBtn) {
      openTermBtn.addEventListener('click', () => {
        const termSection = document.getElementById('terminal-section');
        if (termSection) {
          termSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setTimeout(() => inputEl.focus({ preventScroll: true }), 450);
        }
      });
    }

    window.__execTerminalCmd = executeCommand;
  }
  initInteractiveTerminal();

  // ==========================================================================
  // 10. CHAT CON EL "YO DIGITAL" (VENTANA OS ARRASTRABLE)
  // ==========================================================================
  function initDigitalTwinChat() {
    const fab = document.getElementById('twin-fab');
    const navBtn = document.getElementById('btn-toggle-twin');
    const win = document.getElementById('twin-window');
    const closeBtn = document.getElementById('twin-close');
    const dragHandle = document.getElementById('twin-drag-handle');
    const messagesEl = document.getElementById('twin-messages');
    const form = document.getElementById('twin-form');
    const input = document.getElementById('twin-input');
    const chips = document.querySelectorAll('.twin-chip[data-question]');

    if (!fab || !win || !messagesEl || !form || !input) return;

    function addMsg(text, sender) {
      const div = document.createElement('div');
      div.className = `twin-msg ${sender}`;
      div.textContent = text;
      messagesEl.appendChild(div);
      messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    addMsg('¡Hola! Soy el Yo Digital de Rafa. Pregúntame sobre su stack, el PC 3D, proyectos o disponibilidad.', 'bot');

    function answerQuestion(q) {
      const text = q.toLowerCase();
      if (text.includes('stack') || text.includes('tecnolog') || text.includes('lenguaje')) {
        return 'Trabajo full-stack con JavaScript/TypeScript, React, Three.js en frontend; Node.js, Python y Java en backend; y PostgreSQL, Redis, MongoDB y Docker en datos/cloud.';
      }
      if (text.includes('3d') || text.includes('three') || text.includes('pc')) {
        return 'El PC 3D está construido 100% de forma procedimental en pc3d.js con Three.js, iluminación PMREM, Bloom post-processing y raycasting para saltar a cada sección haciendo clic en las piezas.';
      }
      if (text.includes('proyect') || text.includes('demo')) {
        return 'Destaco 3 proyectos con demo viva integrada aquí mismo: el Explorador PC 3D, el Telemetry & Auth API Hub (con sandbox REST) y el Cloud Cluster Orchestrator (con escalado Docker interactivo).';
      }
      if (text.includes('experienc') || text.includes('trayector') || text.includes('formac')) {
        return 'Desde 2022 he evolucionado desde algoritmia y OOP en Java hacia APIs robustas en Node.js/Python, contenedores Docker con CI/CD y actualmente arquitectura interactiva WebGL 3D.';
      }
      if (text.includes('disponib') || text.includes('trabaj') || text.includes('contrat') || text.includes('remoto')) {
        return 'Estoy disponible para nuevas oportunidades y proyectos desafiantes (full-stack, backend o frontend interactivo). Puedes ver mi CV clásico arriba o escribirme por correo/LinkedIn.';
      }
      if (text.includes('contact') || text.includes('correo') || text.includes('email') || text.includes('github')) {
        return 'Puedes ver mi GitHub en github.com/Rafags04 o enviarme un correo directo desde la sección de Contacto (incluye botón de copiar rápido).';
      }
      return 'Buena pregunta. Puedo contarte sobre mi stack técnico, cómo construí este portfolio 3D sin .glb, mis demos en vivo o mi disponibilidad actual.';
    }

    function toggleChat(forceState) {
      const willOpen = typeof forceState === 'boolean' ? forceState : win.classList.contains('is-hidden');
      win.classList.toggle('is-hidden', !willOpen);
      fab.setAttribute('aria-expanded', String(willOpen));
      if (willOpen) {
        setTimeout(() => input.focus(), 100);
      }
    }

    fab.addEventListener('click', () => toggleChat());
    if (navBtn) navBtn.addEventListener('click', () => toggleChat());
    if (closeBtn) closeBtn.addEventListener('click', () => toggleChat(false));

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = input.value.trim();
      if (!val) return;
      addMsg(val, 'user');
      input.value = '';
      setTimeout(() => addMsg(answerQuestion(val), 'bot'), 220);
    });

    chips.forEach((c) => {
      c.addEventListener('click', () => {
        const q = c.getAttribute('data-question');
        addMsg(q, 'user');
        setTimeout(() => addMsg(answerQuestion(q), 'bot'), 200);
      });
    });

    // Ventana flotante arrastrable estilo OS
    if (dragHandle) {
      let dragging = false;
      let startX = 0;
      let startY = 0;
      let startLeft = 0;
      let startTop = 0;

      dragHandle.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) return;
        dragging = true;
        const rect = win.getBoundingClientRect();
        win.style.right = 'auto';
        win.style.bottom = 'auto';
        win.style.left = `${rect.left}px`;
        win.style.top = `${rect.top}px`;
        startX = e.clientX;
        startY = e.clientY;
        startLeft = rect.left;
        startTop = rect.top;
      });

      window.addEventListener('mousemove', (e) => {
        if (!dragging) return;
        const maxLeft = window.innerWidth - win.offsetWidth - 8;
        const maxTop = window.innerHeight - win.offsetHeight - 8;
        const nextLeft = Math.max(8, Math.min(maxLeft, startLeft + (e.clientX - startX)));
        const nextTop = Math.max(8, Math.min(maxTop, startTop + (e.clientY - startY)));
        win.style.left = `${nextLeft}px`;
        win.style.top = `${nextTop}px`;
      });

      window.addEventListener('mouseup', () => {
        dragging = false;
      });
    }
  }
  initDigitalTwinChat();

  // ==========================================================================
  // 11. MODO CV CLÁSICO (ALTERNATIVA RÁPIDA & IMPRIMIBLE)
  // ==========================================================================
  const classicOverlay = document.getElementById('classic-cv-overlay');
  const openCvBtns = [
    document.getElementById('btn-classic-cv'),
    document.getElementById('btn-hero-classic-cv'),
    document.getElementById('btn-footer-classic-cv')
  ];
  const closeCvBtn = document.getElementById('btn-close-classic-cv');
  const printCvBtn = document.getElementById('btn-print-cv');

  function openClassicCV() {
    if (!classicOverlay) return;
    if (navMenu) navMenu.classList.remove('is-active');
    if (navToggle) navToggle.setAttribute('aria-expanded', 'false');
    appState.classicCvOpen = true;
    classicOverlay.classList.remove('is-hidden');
    document.body.classList.add('modal-open');
    if (window.pcViewer && typeof window.pcViewer.setPaused === 'function') {
      window.pcViewer.setPaused(true);
    }
  }

  function closeClassicCV() {
    if (!classicOverlay) return;
    appState.classicCvOpen = false;
    classicOverlay.classList.add('is-hidden');
    document.body.classList.remove('modal-open');
    if (window.pcViewer && typeof window.pcViewer.setPaused === 'function') {
      window.pcViewer.setPaused(false);
    }
  }

  openCvBtns.forEach((b) => {
    if (b) b.addEventListener('click', openClassicCV);
  });
  if (closeCvBtn) closeCvBtn.addEventListener('click', closeClassicCV);
  if (printCvBtn) {
    printCvBtn.addEventListener('click', () => window.print());
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && appState.classicCvOpen) {
      closeClassicCV();
    }
  });

  // Copiar correo al portapapeles
  const copyEmailBtn = document.getElementById('btn-copy-email');
  if (copyEmailBtn) {
    copyEmailBtn.addEventListener('click', async () => {
      const email = 'tu-correo@ejemplo.com';
      try {
        await navigator.clipboard.writeText(email);
        showToast('Correo copiado', `${email} guardado en el portapapeles.`);
      } catch (_) {
        showToast('Correo de contacto', email);
      }
    });
  }

  // ==========================================================================
  // 12. EASTER EGGS: CÓDIGO KONAMI & CONSOLA DE DESARROLLADOR (F12)
  // ==========================================================================
  const KONAMI_SEQ = [
    'ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown',
    'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight',
    'b', 'a'
  ];
  let konamiIndex = 0;

  document.addEventListener('keydown', (e) => {
    if (e.target && ['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;
    const expected = KONAMI_SEQ[konamiIndex];
    if (e.key === expected || e.key.toLowerCase() === expected) {
      konamiIndex++;
      if (konamiIndex === KONAMI_SEQ.length) {
        konamiIndex = 0;
        setOverclock(true);
        setMatrixRain(true);
        showToast('¡Código Konami Desbloqueado!', 'Modo Overclock 6.2GHz + Lluvia Matrix activados.');
      }
    } else {
      konamiIndex = 0;
    }
  });

  // Consola para desarrolladores curiosos
  window.rafa = {
    help() {
      console.log('Comandos rápidos: rafa.overclock(), rafa.matrix(), rafa.theme("neon"), rafa.cv(), rafa.persona("developer")');
    },
    overclock(on = !appState.overclock) {
      setOverclock(on);
    },
    matrix(on = !appState.matrixRain) {
      setMatrixRain(on);
    },
    theme(key) {
      applyTheme(key);
    },
    cv() {
      openClassicCV();
    },
    persona(p) {
      setVisitorPersona(p);
    }
  };

  console.log(
    '%c<Rafa.dev/> %cBienvenido a la consola de ingeniería.',
    'color: #00f0ff; font-size: 16px; font-weight: bold;',
    'color: #94a3b8; font-size: 12px;'
  );
  console.log('Tip secreto: ejecuta rafa.help() o introduce el Código Konami (↑↑↓↓←→←→BA) en la página.');
});
